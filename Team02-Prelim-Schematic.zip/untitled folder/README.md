# lightcycle-team02-ece411
A repository that'll host the documentation, support info, and source files for Team 02's practicum project. 
